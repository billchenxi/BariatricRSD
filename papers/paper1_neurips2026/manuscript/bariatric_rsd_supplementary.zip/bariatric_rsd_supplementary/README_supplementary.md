# Supplementary Material — Overleaf upload

Standalone supplementary PDF for the NeurIPS 2026 E&D submission.
Contains everything not in the 9-page main paper:

- Appendix A — Implementation details
- Appendix B — Hyperparameter sensitivity
- Appendix C — Per-fold and per-seed tables (5-fold × 3-seed)
- Appendix D — Negative result: per-video frame filtering
- Appendix E — Failure modes
- Appendix F — Shuffled-token semantic control
- Appendix Z — Extended discussion
- References

How to use: New Project → Upload Project → upload this zip.
Set Main Document to main.tex.
